CREATIVE STUDIO — PREMIUM PORTFOLIO WEBSITE

Included:
- index.html: responsive black-and-gold portfolio website.
- Six original CSS-built sample portfolio concepts.
- Services, studio/about section, sample starter pricing and parent-supervised enquiry guidance.

Preview:
Open index.html in a web browser.

Before publishing:
1. Replace sample concepts with your own original design work as you create it.
2. Replace the mailto: link with a parent-managed email address (do not use a minor's personal contact details).
3. Have a parent/guardian review the website, contact setup, customer requests and payment arrangements.
4. Publish using a free static hosting service, following its current age and account rules.

This is a static portfolio site. It does not process payments or collect orders. Sample portfolio pieces are illustrative concepts, not real client commissions. Starter prices are examples, not guaranteed income.
